package sk.novotnyr.movies.web;

import java.io.IOException;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.ws.client.core.SourceExtractor;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.core.SoapActionCallback;
import org.springframework.xml.transform.StringSource;

/**
 * Klient pre webov� slu�bu konfigurovan� z XML aplika�n�ho kontextu Springu.
 * @author Administrator
 *
 */
public class SpringClient {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("sk/novotnyr/movies/web/spring-ws-client.xml");
		WebServiceTemplate webServiceTemplate = (WebServiceTemplate) ctx.getBean("webServiceTemplate");
		webServiceTemplate.setDefaultUri("http://localhost:8080/movie-ws/");
	
		SoapActionCallback soapActionCallback = new SoapActionCallback("http://movies/movieReservation");
		
		Source poziadavka = new StringSource("<m:hello xmlns:m='http://movies'>25s</m:hello>");
		webServiceTemplate.sendSourceAndReceiveToResult(poziadavka, soapActionCallback, new StreamResult(System.out));
		
	}
}
