package sk.novotnyr.movies.web;

import org.mortbay.jetty.Server;
import org.mortbay.jetty.webapp.WebAppContext;


/**
 * Na�tartuje Jetty a spust� v �om webov� aplik�ciu
 * s webovou slu�bou. Mo�no sp���a� priamo v Eclipse,
 * odstra�uje nutnos� ma� nakonfigurovan� Tomcat.
 *
 */
public class JettyRunner {
	public static void main(String[] args) throws Exception {
	
		Server server = new Server(8080);
		
		WebAppContext webappcontext = new WebAppContext();
		webappcontext.setContextPath("/movie-ws");
		webappcontext.setWar("./web");
	
		server.setHandler(webappcontext);
		server.start();
		
	}
}
