package sk.novotnyr.movies.ws;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.springframework.ws.server.endpoint.PayloadEndpoint;
import org.springframework.xml.transform.StringSource;

public class MovieReservationEndPoint implements PayloadEndpoint {

	@Override
	public Source invoke(Source request) throws Exception {
		try {
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.transform(request, new StreamResult(System.out));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new StringSource("<m:helloResponse xmlns:m='http://movies'>Hello Received</m:helloResponse>");
	}
	
	
}